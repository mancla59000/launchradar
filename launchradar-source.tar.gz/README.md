# 🎯 LaunchRadar - Intelligence Économique Personnelle

**Version:** 1.0 Personal Edition  
**Status:** Development Phase Complete - Ready for MCP Deployment  
**Budget:** 41€/mois (15€ sous budget 56€/mois)  
**Timeline:** 8 semaines MVP personnel  

---

## 📊 RÉSUMÉ EXÉCUTIF

LaunchRadar est votre outil personnel d'intelligence économique pour identifier les opportunités micro-SaaS avant qu'elles deviennent saturées. La plateforme surveille automatiquement Twitter et Reddit, score les opportunités avec IA, et vous fournit un dashboard personnel pour gérer vos recherches.

### 🎯 **Objectifs Personnels**
- **Identifier** les opportunités émergentes avant saturation marché
- **Analyser** avec scoring IA 4 facteurs (Relevance, Engagement, Authority, Freshness)  
- **Organiser** vos recherches avec notes personnelles et export
- **Économiser** temps de veille manuelle (2x plus efficace)

---

## 🏗️ ARCHITECTURE TECHNIQUE

### **Stack Technologique**
- **Frontend:** Next.js 15 + TypeScript + TailwindCSS
- **Backend:** Supabase + PostgreSQL + Row Level Security
- **Infrastructure:** Hetzner CPX21 (3vCPU, 8GB) + Docker
- **APIs:** Twitter API v2 + Reddit API (free tiers)
- **Monitoring:** Uptime Kuma + SSL Let's Encrypt

### **Budget Optimisé (41€/mois)**
```
🏗️ Infrastructure:
   - Hetzner CPX21: 20€/mois
   - Supabase Pro: 15€/mois
   - Domain + SSL: 1€/mois
   - Monitoring: 5€/mois
   
💰 Total: 41€/mois (15€ sous budget 56€/mois)
```

---

## 📋 PHASE DEVELOPMENT - LIVRABLES TERMINÉS

### ✅ **BUSINESS ANALYST** 
**Livrable:** `ai/project-brief.md` (923 mots)
- Vision business claire: Intelligence économique micro-SaaS
- Analyse marché: TAM/SAM/SOM + stakeholders
- Objectifs: 4k€ MRR, 200 users, >80% précision scoring

### ✅ **PRODUCT MANAGER**
**Livrable:** `ai/prd.md` (Version personnelle adaptée)
- 8 User Stories détaillées usage personnel
- 5 Epics: Data Collection, Dashboard, BI, Infrastructure, Monetization
- Roadmap 8 semaines avec adaptation personal research

### ✅ **SOLUTION ARCHITECT**
**Livrable:** `ai/architecture-doc.md` (47 pages)
- Architecture scalable Docker + Hetzner + Supabase
- Schéma database complet avec RLS
- Plan déploiement sécurisé avec SSL

### ✅ **DEVOPS AGENT**
**Livrables:**
- `docker/docker-compose.yml` avec Uptime Kuma
- `scripts/deploy-hetzner.sh` automatisation complète
- Configuration Nginx + SSL + sécurité
- Budget: 20€/mois infrastructure

### ✅ **BACKEND AGENT** 
**Livrables:**
- 15 API endpoints Next.js avec TypeScript
- Services: Scoring, Processing, Notes, Export, Collection
- Integration Twitter API v2 + Reddit API
- Database schema Supabase avec migration
- Budget: 15€/mois Supabase Pro

### ✅ **FRONTEND AGENT**
**Livrables:**
- Dashboard personnel responsive 4-colonnes
- Composants: OpportunityCard, PersonalNotes, FilterPanel, ExportButton
- Système notes Markdown avec tags
- Export multi-formats (CSV, JSON, PDF)
- Mobile-first design TailwindCSS

---

## 🚀 FONCTIONNALITÉS PRINCIPALES

### **1. Surveillance Automatique 24/7**
- **Sources:** Twitter + Reddit r/entrepreneur  
- **Mots-clés:** #buildinpublic, #indiehackers, #SaaS, MRR, revenue, $
- **Volume:** 500 posts/jour analysés
- **APIs:** Free tiers Twitter v2 + Reddit

### **2. Scoring IA Personnel**
- **Algorithm:** 4 facteurs pondérés
  - Relevance: 40% (mots-clés + contexte)
  - Engagement: 30% (likes, comments, shares)
  - Authority: 20% (profil auteur)
  - Freshness: 10% (récence publication)
- **Précision:** >70% sur évaluation personnelle

### **3. Dashboard Recherche**
- **Interface:** Responsive 4-colonnes → mobile 1-colonne
- **Filtres:** Search, source, catégorie, score, date, tags
- **Stats:** Opportunités totales, high-score, notes, statut collection

### **4. Système Notes Personnel**
- **Format:** Markdown avec prévisualisation
- **Organisation:** Tags personnalisables + recherche full-text
- **Intégration:** Notes par opportunité + notes générales

### **5. Export Multi-Formats**
- **CSV:** Analyse Excel/Google Sheets
- **JSON:** Data complète avec métadonnées  
- **Research Report:** Rapport formaté Markdown

---

## 🔧 MCP SERVERS CONFIGURATION

### **MCP Hetzner Cloud** (Installé)
```bash
Server: hetzner-cloud
Command: npx -y @dkruyt/mcp-hetzner
Features: Servers, Volumes, Firewall, SSH Keys
Security: Read-only mode par défaut
```

### **MCP Supabase** (Installé)  
```bash
Server: supabase
Command: npx -y @supabase/mcp-server-supabase --read-only
Features: Database, Tables, Migrations, Queries
Security: Read-only + project scoping
```

---

## 📁 STRUCTURE PROJET

```
launchradar/
├── .claude/                    # Framework Hybride-Agile
│   ├── agents/                 # Agents spécialisés BMAD
│   ├── context/               # Contexte projet
│   └── workflows/             # Workflows orchestration
├── ai/                        # Livrables Business/Product/Architecture
│   ├── project-brief.md       # Business Analyst (923 mots)
│   ├── prd.md                 # Product Manager (version personnelle)
│   └── architecture-doc.md    # Solution Architect (47 pages)
├── src/                       # Code source Next.js
│   ├── app/                   # App Router Next.js 15
│   ├── components/            # Composants React
│   ├── lib/                   # Services et utilitaires
│   └── types/                 # Types TypeScript
├── docker/                    # Configuration Docker
│   ├── docker-compose.yml     # Stack complète
│   └── nginx/                 # Configuration reverse proxy
├── scripts/                   # Scripts déploiement
│   ├── deploy-hetzner.sh      # Déploiement automatisé
│   └── setup-backend.sh       # Configuration backend
└── supabase/                  # Database & migrations
    ├── config.toml            # Configuration Supabase
    └── migrations/            # Scripts SQL
```

---

## 🎯 STATUT ACTUEL

### ✅ **PHASES TERMINÉES**
1. **Planning:** Business Brief + PRD + Architecture (100%)
2. **Development:** DevOps + Backend + Frontend (100%)

### 🔄 **PHASE SUIVANTE: MCP DEPLOYMENT**
**Prérequis:** Redémarrage Claude Code pour activation MCP servers

### 🎯 **OBJECTIFS DEPLOYMENT**
1. **Hetzner VPS:** Provision CPX21 via MCP
2. **Supabase Setup:** Project + Database via MCP  
3. **Configuration:** APIs Twitter/Reddit
4. **Tests:** Validation complète pipeline

---

## 💡 PROMPT DE REPRISE APRÈS REDÉMARRAGE

Après redémarrage Claude Code, utilisez ce prompt :

```
🎯 CONTEXTE LAUNCHRADAR - REPRISE DEVELOPMENT

## PROJET
LaunchRadar Personal - Intelligence économique micro-SaaS
Budget: 41€/mois | Timeline: 8 semaines MVP personnel

## STATUT ACTUEL
✅ Phase Planning: Business Brief + PRD + Architecture (100%)
✅ Phase Development: DevOps + Backend + Frontend (100%)
🔄 Phase Deployment: MCP Hetzner + Supabase activation

## LIVRABLES PRÊTS
- Code complet Next.js + Supabase (src/)
- Infrastructure Docker (docker/)
- Scripts déploiement (scripts/)
- Configuration complète (.env.example)

## MCP SERVERS INSTALLÉS
- hetzner-cloud: Provision VPS CPX21 (20€/mois)
- supabase: Setup database + tables

## ACTIONS IMMÉDIATES
1. Vérifier activation MCP servers: ListMcpResourcesTool
2. Provision Hetzner CPX21 via MCP si disponible
3. Setup Supabase project via MCP si disponible
4. Configuration APIs Twitter/Reddit
5. Tests complets pipeline

## FICHIERS CLÉS
- README.md: Documentation complète
- ai/: Business Brief + PRD + Architecture
- src/: Code Next.js complet
- docker/: Infrastructure prête

Peux-tu vérifier les MCP servers et commencer le déploiement ?
```

---

## 🔒 SÉCURITÉ & COMPLIANCE

### **Infrastructure**
- SSH hardening (no root, key-only)
- UFW firewall (ports minimaux)
- SSL/TLS Let's Encrypt
- Fail2Ban intrusion prevention

### **Application**  
- Supabase RLS (Row Level Security)
- Authentication Supabase Auth
- API rate limiting
- Data encryption at rest + transit

### **Personnel Data**
- Notes privées chiffrées
- Export contrôlé utilisateur
- Backup automatique sécurisé

---

## 📞 SUPPORT & ÉVOLUTION

### **Phase MVP (8 semaines)**
Focus usage personnel avec features core complètes

### **Phase Commercialisation (Futur)**
Architecture déjà prête pour scale:
- Multi-tenant avec RLS
- Système abonnements Stripe
- API publique développeurs
- Analytics avancées

### **Monitoring & Maintenance**
- Uptime Kuma: Service monitoring
- Health checks: `/api/health`
- Logs centralisés
- Budget tracking automatique

---

**🎯 LaunchRadar Personal - Votre avantage concurrentiel pour identifier les opportunités micro-SaaS avant tout le monde !**

**Status:** Prêt pour déploiement MCP automatisé 🚀