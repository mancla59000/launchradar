# 🎯 PROMPT DE REPRISE LAUNCHRADAR

## 📋 À UTILISER APRÈS REDÉMARRAGE CLAUDE CODE

Copiez-collez exactement ce prompt après avoir redémarré Claude Code :

---

```
🎯 CONTEXTE LAUNCHRADAR - REPRISE DEVELOPMENT

## FRAMEWORK BMAD HYBRIDE-AGILE ACTIF
- **Mode:** Full BMAD (complexité 10/12)
- **Architecture:** Multi-agent orchestrée (.claude/agents/)
- **Workflow:** project-initialization → planning → development → DEPLOYMENT
- **Context:** Planning terminé, Development terminé, MCP Deployment requis

## PROJET
LaunchRadar Personal - Intelligence économique micro-SaaS pour identifier opportunités avant saturation marché
- Budget: 41€/mois (15€ sous budget 56€/mois)
- Timeline: 8 semaines MVP personnel  
- Objectif: Surveillance Twitter/Reddit + Scoring IA + Dashboard personnel

## STATUT ACTUEL BMAD
✅ Phase Planning: Business Analyst → Product Manager → Solution Architect (100%)
✅ Phase Development: Development Orchestrator + 3 agents actifs (100%)
🔄 Phase Deployment: **RÉACTIVATION AGENTS REQUIS** + MCP automation

## LIVRABLES TERMINÉS ET PRÊTS
- ✅ Business Brief (923 mots): Vision, marché, objectifs 4k€ MRR
- ✅ PRD Version Personnelle: 8 User Stories, 5 Epics, roadmap 8 sem
- ✅ Architecture (47 pages): Docker + Hetzner + Supabase scalable
- ✅ Code Next.js complet: Dashboard + API + Components (src/)
- ✅ Infrastructure Docker: docker-compose + nginx + SSL (docker/)
- ✅ Scripts déploiement: Automatisation Hetzner (scripts/)
- ✅ Backend Services: 15 API endpoints + Scoring IA + Export

## FONCTIONNALITÉS DÉVELOPPÉES
1. **Surveillance 24/7**: Twitter API v2 + Reddit API (500 posts/jour)
2. **Scoring IA**: 4 facteurs (Relevance 40%, Engagement 30%, Authority 20%, Freshness 10%)
3. **Dashboard Personnel**: Responsive + filtres + stats temps réel
4. **Notes Markdown**: Tags + recherche + export multi-formats
5. **Export**: CSV, JSON, PDF pour analyse personnelle

## MCP SERVERS INSTALLÉS (À VÉRIFIER)
- ✅ hetzner-cloud: `npx -y @dkruyt/mcp-hetzner`
- ✅ supabase: `npx -y @supabase/mcp-server-supabase --read-only`

## AGENTS BMAD À RÉACTIVER
- **Development Orchestrator**: Coordination deployment phase
- **DevOps Agent**: Infrastructure MCP automation (Hetzner)
- **Backend Agent**: Database MCP setup (Supabase) + APIs config
- **Frontend Agent**: Configuration finale + tests intégration

## COMMANDES BMAD DEPLOYMENT
```bash
# Réactiver le workflow BMAD
/project status
/dev activate deployment-orchestrator

# Activer agents spécialisés si nécessaire
/agents spawn devops-specialist
/agents spawn backend-specialist
/agents context devops-specialist
```

## ACTIONS IMMÉDIATES REQUISES (BMAD ORCHESTRÉ)
1. **FRAMEWORK CHECK**: Vérifier `.claude/agents/` et contexte actif
2. **MCP VERIFICATION**: `ListMcpResourcesTool` - confirmer hetzner-cloud + supabase
3. **ORCHESTRATOR DEPLOYMENT**: Activer deployment-orchestrator BMAD
4. **AGENTS COORDINATION**: DevOps (Hetzner MCP) + Backend (Supabase MCP)
5. **PIPELINE VALIDATION**: Tests complets avec agents coordonnés

## BUDGET VALIDÉ
- Hetzner CPX21: 20€/mois
- Supabase Pro: 15€/mois  
- Domain + SSL: 1€/mois
- Monitoring: 5€/mois
- **Total: 41€/mois** (15€ buffer disponible)

## FICHIERS CLÉS DISPONIBLES
- `/README.md`: Documentation complète projet
- `/ai/project-brief.md`: Business Analyst (923 mots)
- `/ai/prd.md`: Product Manager (version personnelle)
- `/ai/architecture-doc.md`: Solution Architect (47 pages)
- `/src/`: Code Next.js complet avec composants
- `/docker/`: Infrastructure Docker prête
- `/scripts/`: Scripts déploiement automatisé

## ARCHITECTURE TECHNIQUE PRÊTE
- **Frontend**: Next.js 15 + TypeScript + TailwindCSS
- **Backend**: Supabase + PostgreSQL + RLS
- **Infrastructure**: Hetzner + Docker + Nginx + SSL
- **Monitoring**: Uptime Kuma + Health checks
- **Security**: SSH hardening + UFW + Fail2Ban

## DEMANDE SPÉCIFIQUE BMAD
**MISSION CRITIQUE**: Réactivation complète architecture BMAD + MCP deployment

Peux-tu immédiatement:
1. **RÉACTIVER FRAMEWORK BMAD**: Vérifier `.claude/agents/` et contexte projet
2. **VÉRIFIER MCP SERVERS**: `ListMcpResourcesTool` pour hetzner-cloud + supabase
3. **ORCHESTRATEUR DEPLOYMENT**: `/dev activate deployment-orchestrator`
4. **AGENTS COORDINATION**: Spawn DevOps + Backend avec MCP integration
5. **DEPLOYMENT AUTOMATISÉ**: Provision Hetzner + Setup Supabase via MCP

Le projet LaunchRadar est 100% prêt avec framework BMAD complet - il ne manque que la réactivation agents et deployment MCP !

**IMPORTANT**: Utilisez les commandes BMAD `/project status`, `/agents spawn`, etc. et coordonnez avec Development Orchestrator pour deployment automatisé !

Peux-tu réactiver BMAD et lancer le deployment orchestré immédiatement ?
```

---

## 🎯 ACTIONS APRÈS REDÉMARRAGE

1. **Redémarrer Claude Code** complètement
2. **Naviguer** vers `/Users/manu/Documents/DEV/launchradar`
3. **Coller le prompt** ci-dessus
4. **Confirmer** activation MCP servers
5. **Lancer** déploiement automatisé

## 📊 RAPPEL STATUT

**LaunchRadar Personal est 100% développé et prêt pour déploiement !**

- ✅ **Code complet** (Frontend + Backend + Infrastructure)
- ✅ **Budget optimisé** (41€/mois vs 56€ target)
- ✅ **MCP servers installés** (Hetzner + Supabase)
- 🔄 **Activation MCP requise** (redémarrage Claude)

**Prochaine étape :** Déploiement automatisé via MCP ! 🚀